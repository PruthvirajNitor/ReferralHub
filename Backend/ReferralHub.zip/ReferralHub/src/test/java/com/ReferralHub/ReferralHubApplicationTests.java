package com.ReferralHub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReferralHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
