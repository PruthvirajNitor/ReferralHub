package com.ReferralHub.entities;

public enum Skills {

    SQL,PYTHON,JAVA,AI,HTML,CSS,JAVASCRIPT,REACT,MONGODB,AWS,MACHINE_LEARNING,SPRING_BOOT
}
