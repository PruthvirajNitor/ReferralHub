package com.ReferralHub.entities;

public enum Status {

    APPLIED,SHORTLISTED,INTERVIEWED,REJECTED,HIRED
}
