package com.ReferralHub.entities;

public enum Role {

    HR,ADMIN,EMPLOYEE

}
