package com.ReferralHub.entities;





public enum Department {

    HR, DEVOPS,IT, DEVELOPMENT, AI, DATA_ENGINEERING, SUPPORT, FINANCE, INFRASTRUCTURE, SALES, MARKETING

}
