<template>
    <h1>Something</h1>
  </template>
  
  <script>
  
  export default {
      components:{}
  }
  </script>
  
  <style>
  
  </style>