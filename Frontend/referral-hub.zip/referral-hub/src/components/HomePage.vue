<template>
  <sign-in></sign-in>
  <the-register></the-register>
  
</template>

<script>
import SignIn from './nav/SignIn.vue'
import TheRegister from './nav/TheRegister.vue'
export default {
  components: {  TheRegister, SignIn,  },

}
</script>

<style>

</style>